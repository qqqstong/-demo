"""Create faithful announcement excerpts, not precomputed answers."""
from pathlib import Path
import json
import pdfplumber
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfgen import canvas
from reportlab.lib.utils import simpleSplit

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/Users/qst3.0/Desktop/基金公告运营助手.pdf')
pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))
regions = {
    'A': [(1, 282, 750), (2, 40, 332)],
    'B': [(2, 338, 750), (3, 40, 430)],
    'C': [(3, 436, 750), (4, 40, 750), (5, 40, 200)],
}
with pdfplumber.open(SOURCE) as doc:
    for key, parts in regions.items():
        target = ROOT / 'samples' / f'公告{key}.pdf'
        c = canvas.Canvas(str(target), pagesize=(612, 792))
        for i, top, bottom in parts:
            text = doc.pages[i].crop((30, top, 583, bottom)).extract_text() or ''
            c.setFont('STSong-Light', 10)
            c.setFillColorRGB(.3, .4, .4)
            c.drawString(40, 758, f'题目公告原文摘录 · 公告{key} · 原始材料第{i+1}页')
            c.setFillColorRGB(0, 0, 0)
            y = 728
            for line in text.splitlines():
                for segment in simpleSplit(line, 'STSong-Light', 11, 528):
                    if y < 44:
                        c.showPage(); c.setFont('STSong-Light', 11); y = 748
                    c.setFont('STSong-Light', 11)
                    c.drawString(40, y, segment); y -= 18
            c.showPage()
        c.save()
    # Product profile is separate from announcement evidence and is labelled as such.
    profile = {'source': '考试材料一（虚构）', 'name': '恒远均衡成长混合型证券投资基金',
               'code': '019001', 'share_classes': {'A': '019001', 'C': '019002'},
               'default_dividend_method': '现金分红', 'risk': 'R3'}
    (ROOT / 'product_profile.json').write_text(json.dumps(profile, ensure_ascii=False, indent=2))
print('Created A/B/C PDFs from original announcement regions; no test questions included.')
