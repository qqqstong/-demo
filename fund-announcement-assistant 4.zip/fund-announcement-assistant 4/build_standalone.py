"""Build a file:// compatible, self-contained preview with explicit offline scope."""
from pathlib import Path
import json, base64
from engine import ROOT, QUESTIONS, parse_pdf, split_documents, analyze
cases={}
for key in 'ABC':
 raw=(ROOT/'samples'/f'公告{key}.pdf').read_bytes()
 pages=split_documents(parse_pdf(raw))[key]
 context={'amount':'20000' if key=='B' else '', 'shares':'25000' if key=='C' else '', 'other_amount':'', 'business_date':'', 'method':'unknown','change_status':'unknown'}
 result=analyze(pages,key,QUESTIONS[key],context)
 cases[key]={'question':QUESTIONS[key],'pages':pages,'result':result,'pdf':base64.b64encode(raw).decode()}
html=(ROOT/'static/index.html').read_text()
css=(ROOT/'static/style.css').read_text()+'''\n#offlinePrint{display:none}.offline-scope{font-size:11px;color:#7c806c;margin:0 0 22px;padding:12px 16px;background:#f0f3e8;border:1px solid #e1e7d7;border-radius:7px;line-height:1.9}@media print{@page{size:A4;margin:20mm}body>*{display:none!important}body>#offlinePrint{display:block!important;color:#17291e;font-size:12pt;line-height:1.8}#offlinePrint h1{font-size:21pt}#offlinePrint h2{font-size:14pt}#offlinePrint li{margin:0 0 12pt;break-inside:avoid}#offlinePrint p{font-size:10pt}}
'''
app=(ROOT/'static/app.js').read_text()
start=app.index('async function api(');end=app.index('function toast(',start)
app=app[:start]+'const api=offlineApi;\n'+app[end:]
app=app.replace("$('pdfLink').href='/api/files/'+state.upload.id;", "$('pdfLink').href='data:application/pdf;base64,'+OFFLINE_CASES[r.type].pdf;")
start=app.index('async function exportFile(');end=app.index("$('fileInput').onchange",start)
app=app[:start]+'const exportFile=offlineExport;\n'+app[end:]
start=app.index("document.querySelectorAll('[data-sample]')");end=app.index("$('pasteButton').onclick",start)
app=app[:start]+'''document.querySelectorAll('[data-sample]').forEach(button=>button.onclick=async()=>{try{const key=button.dataset.sample;setUpload(await api('/api/upload',{filename:`题目公告${key}.pdf`,data:OFFLINE_CASES[key].pdf}),key);busy(false);toast('案例已载入，可修改条件后生成材料');}catch(e){error(e.message);}});\n'''+app[end:]
app=app.replace("await navigator.clipboard.writeText((state.materials[state.material]||'').replace(/\\*\\*(.*?)\\*\\*/g,'$1').replace(/^- /gm,'• '));", "await offlineCopy((state.materials[state.material]||'').replace(/\\*\\*(.*?)\\*\\*/g,'$1').replace(/^- /gm,'• '));")
app=app.replace("state.samples=await api('/api/samples');", "state.samples=await api('/api/samples');setUpload(await api('/api/upload',{filename:'题目公告C.pdf',data:OFFLINE_CASES.C.pdf}),'C');busy(false);await run();tab('materials');")
app+='''\nasync function offlineCopy(text){if(navigator.clipboard){try{await navigator.clipboard.writeText(text);return;}catch(e){}}const box=document.createElement('textarea');box.value=text;box.style.position='fixed';box.style.opacity='0';document.body.append(box);box.select();const ok=document.execCommand('copy');box.remove();if(!ok)throw Error('请手动选择并复制文字');}\n'''
html=html.replace('<link rel="stylesheet" href="/style.css"><script src="/app.js" defer></script>','<style>'+css+'</style>')
html=html.replace('href="/" aria-label','href="#" aria-label').replace('本地演示版','单文件离线版')
html=html.replace('<div class="workspace-grid">','<div class="offline-scope">可直接打开的离线案例演示：A／B／C公告、条件计算、3轮修改、编辑确认及Word导出均可使用。此文件不调用大模型；处理其他公告请使用完整本地版。PDF通过浏览器打印保存。</div><div class="workspace-grid">')
html=html.replace('支持文字版 PDF · 最大 10 MB','支持下方三个案例的原始PDF · 最大 10 MB').replace('原文摘录，无预置答案','内置公告 · 本地规则计算')
html=html.replace('样例为原文摘录重排，页码按本次文件标记。','离线版使用内置案例原文，页码按对应样例标记。')
html=html.replace('便于阅读与分享','打印／存储为PDF')
html=html.replace('当前支持文字版 PDF，扫描件可粘贴正文。','本单文件仅支持内置三个案例及其原始PDF，材料基于本地规则生成；反馈支持精简、语气和明确的份额、金额、日期更正。任意公告解析及模型生成请使用完整本地版。')
html=html.replace('</body>', '<section id="offlinePrint"></section><script>const OFFLINE_CASES='+json.dumps(cases,ensure_ascii=False).replace('</','<\\/')+';\n'+(ROOT/'static/offline.js').read_text()+'\n'+app+'</script></body>')
out=ROOT.parent/'基金公告运营助手-双击打开.html';out.write_text(html); (ROOT/'index.html').write_text(html)
print(out, out.stat().st_size)
