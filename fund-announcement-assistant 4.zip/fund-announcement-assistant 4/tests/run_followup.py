"""Fast HTTP checks for follow-up state, approval invalidation and round limits (rules only)."""
import base64
import http.cookiejar
import json
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def call(path,data=None):
 req=urllib.request.Request('http://127.0.0.1:8765'+path,data=json.dumps(data).encode() if data is not None else None,headers={'Content-Type':'application/json'})
 with client.open(req) as response:return json.load(response)
def complete(ident):
 for _ in range(240):
  job=call('/api/jobs/'+ident)
  if job['status']=='completed':return job
  assert job['status']!='failed',job
  time.sleep(.3)
 raise AssertionError('timeout')
def reject(path,data,phrase):
 try:call(path,data)
 except urllib.error.HTTPError as error:
  assert error.code==400
  assert phrase in json.load(error)['error']
 else:raise AssertionError('Expected rejection')
call('/api/health')
u=call('/api/upload',{'filename':'公告C.pdf','data':base64.b64encode((ROOT/'samples/公告C.pdf').read_bytes()).decode()})
j=complete(call('/api/jobs',{'upload_id':u['id'],'document_id':'C','question':'分红金额是多少？','context':{'shares':'25000'},'engine':'rules'})['id'])
call('/api/jobs/'+j['id']+'/approve',{'revision':j['revision'],'materials':j['result']['materials']})
for i in range(1,4):
 parent=j
 body={'revision':j['revision'],'feedback':f'份额更正为{2500*i}份','materials':j['result']['materials']}
 j=complete(call('/api/jobs/'+j['id']+'/followup',body)['id'])
 assert j['followup_count']==i and len(j['conversation'])==2*(i+1)
 assert j['result']['tools'][0]['result']['amount']==f'{75*i}.00'
 assert not j['approved'] and j['revision']==parent['revision']+1
 reject('/api/jobs/'+parent['id']+'/followup',body,'最新版本')
reject('/api/jobs/'+j['id']+'/followup',{'revision':j['revision'],'feedback':'再简洁一些'},'3轮')
reject('/api/jobs/'+j['id']+'/save',{'revision':j['revision']-1},'版本')
(ROOT/'test-results/v2/反馈接口检查.json').write_text(json.dumps({'mode':'rules, no model','three_rounds':'passed','recalculation':'75.00 / 150.00 / 225.00','conversation_history':'passed','approval_reset':'passed','old_version_followup_rejected':'passed','fourth_round_rejected':'passed','stale_revision_rejected':'passed'},ensure_ascii=False,indent=2))
print('Follow-up HTTP state and three-round limit passed.')
