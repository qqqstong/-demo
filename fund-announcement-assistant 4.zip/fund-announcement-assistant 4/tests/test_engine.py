import copy
import unittest
from engine import ROOT, QUESTIONS, parse_pdf, split_documents, analyze, compact

class AnnouncementTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.docs={k:split_documents(parse_pdf((ROOT/'samples'/f'公告{k}.pdf').read_bytes()))[k] for k in 'ABC'}
 def run_case(self,key,context=None,pages=None):
  return analyze(pages or self.docs[key],key,QUESTIONS[key],context or {})
 def test_manager(self):
  r=self.run_case('A');self.assertEqual(r['facts']['reason']['value'],'工作安排');self.assertEqual(r['facts']['remaining_manager']['value'],'张晨')
 def test_limit_exact(self):
  r=self.run_case('B',{'amount':'10000','other_amount':'0','business_date':'2026-05-08'})
  self.assertIn('未超过',r['claims'][1]['text']);self.assertEqual(r['claims'][1]['status'],'confirmed')
 def test_limit_aggregate(self):
  r=self.run_case('B',{'amount':'8000','other_amount':'3000','business_date':'2026-05-08'})
  self.assertIn('11,000.00',r['claims'][1]['text']);self.assertIn('超过限额',r['claims'][1]['text'])
 def test_before_effective(self):
  r=self.run_case('B',{'amount':'20000','business_date':'2026-05-07'});self.assertIn('尚不适用',r['claims'][1]['text'])
 def test_unknown_other_not_zero(self):
  r=self.run_case('B',{'amount':'8000','business_date':'2026-05-09'});self.assertEqual(r['claims'][1]['status'],'conditional');self.assertIn('other_amount',[x['field'] for x in r['missing']])
 def test_dividend(self):
  r=self.run_case('C',{'shares':'25000'});self.assertEqual(r['tools'][0]['result']['amount'],'750.00');self.assertEqual(r['claims'][1]['status'],'unknown')
 def test_correction(self):
  r=self.run_case('C',{'shares':'2500'});self.assertEqual(r['tools'][0]['result']['amount'],'75.00')
 def test_mutated_distribution(self):
  pages=copy.deepcopy(self.docs['C'])
  for p in pages:p['text']=p['text'].replace('0.30','0.40')
  r=self.run_case('C',{'shares':'25000'},pages);self.assertEqual(r['tools'][0]['result']['amount'],'1000.00')
 def test_mutated_limit(self):
  pages=copy.deepcopy(self.docs['B'])
  for p in pages:p['text']=p['text'].replace('10,000','30,000')
  r=self.run_case('B',{'amount':'20000','other_amount':'0','business_date':'2026-05-09'},pages);self.assertIn('未超过',r['claims'][1]['text'])
 def test_no_fake_method(self):
  r=self.run_case('C',{'shares':'25000','method':'reinvest','change_status':'unknown'});self.assertEqual(r['claims'][1]['status'],'unknown')
 def test_explicit_effective_method(self):
  r=self.run_case('C',{'shares':'25000','method':'reinvest','change_status':'effective'});self.assertIn('按运营补充',r['claims'][1]['text'])
 def test_quotes_exist(self):
  for k in 'ABC':
   r=self.run_case(k,{'shares':'25000','amount':'20000'})
   for e in r['evidence']:self.assertTrue(any(e['quote'] in p['text'] and e['page']==p['page'] for p in self.docs[k]))
 def test_full_exam_excludes_questions(self):
  source=ROOT.parent.parent/'基金公告运营助手.pdf'
  # Optional original file is not needed by the portable bundle.
  if not source.exists():self.skipTest('original exam not in bundle')
  docs=split_documents(parse_pdf(source.read_bytes()))
  self.assertEqual(set(docs),set('ABC'))
  for pages in docs.values():self.assertNotIn('用户可能会问',''.join(p['text'] for p in pages))
 def test_invalid_amount(self):
  with self.assertRaises(ValueError):self.run_case('B',{'amount':'-5'})

if __name__=='__main__':unittest.main()
