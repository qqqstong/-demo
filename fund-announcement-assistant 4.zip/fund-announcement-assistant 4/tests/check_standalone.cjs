const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync('../基金公告运营助手-双击打开.html','utf8');
const scripts=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)];assert.equal(scripts.length,1);const code=scripts[0][1];new vm.Script(code);
assert(!/<(?:script|link)\b[^>]*(?:src|href)=["']\//i.test(html),'external dependency');
const ids=new Set([...html.matchAll(/\bid="([^"]+)"/g)].map(x=>x[1]));
for(const m of code.matchAll(/\$\('([^']+)'\)/g))assert(ids.has(m[1]),'Missing HTML id '+m[1]);
const boundary=code.indexOf("'use strict';");assert(boundary>0);
const ctx=vm.createContext({TextEncoder,Blob,URL,console,setTimeout});
vm.runInContext(code.slice(0,boundary)+`\n(async()=>{
 const samples=await offlineApi('/api/samples');if(samples.length!==3)throw Error('cases');
 for(const key of 'ABC'){
  const upload=await offlineApi('/api/upload',{filename:key+'.pdf',data:OFFLINE_CASES[key].pdf});
  const context={amount:key==='B'?'20000':'',shares:key==='C'?'25000':'',other_amount:'',method:'unknown',change_status:'unknown',business_date:''};
  let job=await offlineApi('/api/jobs',{upload_id:upload.id,document_id:key,question:OFFLINE_CASES[key].question,context});
  if(!job.result.materials.customer.startsWith('- **'))throw Error('bullets');
  if(key==='A'&&!job.result.materials.customer.includes('工作安排'))throw Error('reason');
  if(key==='B'&&!job.result.materials.customer.includes('超过'))throw Error('limit');
  if(key==='C'){
   if(!job.result.materials.customer.includes('750.00'))throw Error('dividend');
   for(let i=1;i<=3;i++){
    job=await offlineApi('/api/jobs/'+job.id+'/followup',{revision:job.revision,feedback:'份额更正为'+(2500*i)+'份，再简洁一些'});
    if(!job.result.materials.customer.includes((75*i)+'.00'))throw Error('correction');
   }
   let blocked=false;try{await offlineApi('/api/jobs/'+job.id+'/followup',{revision:job.revision,feedback:'再简洁一些'});}catch(e){blocked=true;}if(!blocked)throw Error('round limit');
  }
  const word=offlineWord('离线案例'+key,job.result.materials.customer.split('\\n'));
  await outputWord(key,await word.arrayBuffer());
 }
 let blocked=false;try{await offlineApi('/api/upload',{filename:'unknown.pdf',data:'fake'});}catch(e){blocked=true;}if(!blocked)throw Error('unsupported PDF');
 if(dividend('25000','10','0.30')!=='750.00'||dividend('2500','10','0.30')!=='75.00')throw Error('decimal');
 console.log('PASS: single-file syntax, embedded resources, DOM IDs, three cases, exact dividend calculation, three follow-ups, unsupported files and Word ZIP generation.');
})();`,Object.assign(ctx,{outputWord:async(key,data)=>{fs.mkdirSync('test-results/standalone',{recursive:true});fs.writeFileSync('test-results/standalone/案例'+key+'-离线.docx',Buffer.from(data));}}));
