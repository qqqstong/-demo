"""Exercise real upload -> processing -> edit -> approval -> export over HTTP."""
import base64
import http.cookiejar
import json
import time
import urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
BASE='http://127.0.0.1:8765'
jar=http.cookiejar.CookieJar()
client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
OUT=ROOT/'test-results';OUT.mkdir(exist_ok=True)

def api(path, data=None):
 req=urllib.request.Request(BASE+path,data=json.dumps(data).encode() if data is not None else None,
  headers={'Content-Type':'application/json'} if data is not None else {})
 with client.open(req,timeout=20) as r:
  content=r.read()
  return json.loads(content) if r.headers.get_content_type()=='application/json' else content.decode()

api('/api/health')
samples=api('/api/samples')
results=[]
for key in 'ABC':
 binary=(ROOT/'samples'/f'公告{key}.pdf').read_bytes()
 up=api('/api/upload',{'filename':f'公告{key}.pdf','data':base64.b64encode(binary).decode()})
 assert up['documents'][0]['id']==key
 job=api('/api/jobs',{'upload_id':up['id'],'document_id':key,'question':next(s['question'] for s in samples if s['id']==key),
  'context':{'amount':'20000' if key=='B' else '', 'shares':'25000' if key=='C' else ''},'engine':'codex'})
 print(key,'uploaded, actual GPT job',job['id'],flush=True)
 for _ in range(160):
  r=api('/api/jobs/'+job['id'])
  if r['status'] in ('completed','failed'):break
  time.sleep(1)
 assert r['status']=='completed',r
 out=r['result']
 assert out['facts']['fund_code']['value']=='019001'
 for e in out['evidence']:
  assert any(e['quote'] in p['text'] and e['page']==p['page'] for p in out['pages'])
 if key=='A':
  assert out['facts']['reason']['value']=='工作安排'
  assert out['facts']['remaining_manager']['value']=='张晨'
 if key=='B':
  assert out['facts']['limit_amount']['value']=='10000'
  assert '20,000.00' in out['tools'][0]['result'] and '超过限额' in out['tools'][0]['result']
 if key=='C':
  assert out['tools'][0]['result']['amount']=='750.00'
  assert out['claims'][1]['status']=='unknown'
 approval=api('/api/jobs/'+job['id']+'/approve',{'revision':r['revision'],'materials':out['materials']})
 assert approval['approved']
 exported=api('/api/jobs/'+job['id']+'/export')
 assert '已人工确认' in exported and '原文证据' in exported
 (OUT/f'案例{key}-实际结果.json').write_text(json.dumps(r,ensure_ascii=False,indent=2))
 (OUT/f'案例{key}-运营材料.md').write_text(exported)
 results.append({'case':key,'job_id':job['id'],'engine':out['engine'],'model_success':'model_call' in out,'model_error':out.get('model_error'),
 'seconds':r['elapsed_seconds'],'assertions':'passed','evidence_count':len(out['evidence'])})
 (OUT/'运行汇总.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
 print(key,results[-1],flush=True)
print('All three upload-to-export cases passed.',flush=True)
