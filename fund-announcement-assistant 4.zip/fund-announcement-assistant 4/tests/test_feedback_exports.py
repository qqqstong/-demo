import io
import unittest
from docx import Document
import pdfplumber
from engine import ROOT, QUESTIONS, parse_pdf, split_documents, analyze
from server import feedback_context
from exports import render_export, bullet_text

class FeedbackAndExportTests(unittest.TestCase):
 def test_share_correction(self):
  self.assertEqual(feedback_context({'shares':'25000'},'不是25000份，份额更正为2500份。')['shares'],'2500')
 def test_wan_unit(self):
  self.assertEqual(feedback_context({},'持有份额改成2.5万份')['shares'],'25000.0')
 def test_amount_correction(self):
  self.assertEqual(feedback_context({},'单次定投金额改为8000元')['amount'],'8000')
 def test_date(self):
  self.assertEqual(feedback_context({},'扣款日为2026年5月7日')['business_date'],'2026-05-07')
 def test_question_not_correction(self):
  c={'shares':'25000','method':'unknown'}
  self.assertEqual(feedback_context(c,'为什么每10份分红0.30元？我想选再投资。'),c)
 def test_bullet_preserves_decimal_and_conditions(self):
  text=bullet_text('若具备权益，分红为750.00元。方式仍待核实。')
  self.assertEqual(text,'- 若具备权益，分红为750.00元。\n- 方式仍待核实。')
 def test_bullet_heading_merges_with_content(self):
  self.assertEqual(bullet_text("- **金额**\n- 分红为750.00元。"),"- **金额**：分红为750.00元。")
 def test_exports_are_real_and_readable(self):
  pages=split_documents(parse_pdf((ROOT/'samples/公告C.pdf').read_bytes()))['C']
  result=analyze(pages,'C',QUESTIONS['C'],{'shares':'25000'})
  result['filename']='测试公告.pdf'
  job={'result':result,'approved':False,'revision':2}
  docx,mime=render_export(job,'docx','customer')
  self.assertTrue(docx.startswith(b'PK'))
  doc=Document(io.BytesIO(docx))
  self.assertTrue(any(p.style.name=='List Bullet' for p in doc.paragraphs))
  self.assertIn('750.00',''.join(p.text for p in doc.paragraphs))
  pdf,mime=render_export(job,'pdf','customer')
  self.assertTrue(pdf.startswith(b'%PDF-'))
  with pdfplumber.open(io.BytesIO(pdf)) as f:
   text=''.join(p.extract_text() or '' for p in f.pages)
  self.assertIn('750.00',text);self.assertIn('未审核草稿',text)
  md,mime=render_export(job,'md','customer')
  self.assertIn('- **本次分红金额**',md.decode())

if __name__=='__main__':unittest.main()
