"""Real regression: each exam case, bullet materials and all three export formats."""
import base64
import http.cookiejar
import io
import json
import time
import urllib.request
from pathlib import Path
from docx import Document
import pdfplumber

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'test-results'/'v2';OUT.mkdir(exist_ok=True)
client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
BASE='http://127.0.0.1:8765'

def request(path,data=None):
 req=urllib.request.Request(BASE+path,data=json.dumps(data).encode() if data is not None else None,headers={'Content-Type':'application/json'} if data is not None else {})
 with client.open(req,timeout=25) as response:
  raw=response.read();return json.loads(raw) if response.headers.get_content_type()=='application/json' else raw

request('/api/health');samples=request('/api/samples');rows=[]
for key in 'ABC':
 upload=request('/api/upload',{'filename':f'公告{key}.pdf','data':base64.b64encode((ROOT/'samples'/f'公告{key}.pdf').read_bytes()).decode()})
 # No engine choice: this is exactly the normal operator's automatic path.
 created=request('/api/jobs',{'upload_id':upload['id'],'document_id':key,'question':next(s['question'] for s in samples if s['id']==key),
                             'context':{'amount':'20000' if key=='B' else '', 'shares':'25000' if key=='C' else ''}})
 print(key,'running',created['id'],flush=True)
 for _ in range(170):
  job=request('/api/jobs/'+created['id'])
  if job['status'] in ('completed','failed'):break
  time.sleep(1)
 assert job['status']=='completed',job
 r=job['result'];assert 'model_call' in r, r.get('model_error')
 for text in r['materials'].values():
  assert text.startswith('- '),text
 if key=='A':assert r['facts']['reason']['value']=='工作安排'
 if key=='B':assert '超过限额' in r['tools'][0]['result']
 if key=='C':assert r['tools'][0]['result']['amount']=='750.00'
 request('/api/jobs/'+job['id']+'/approve',{'revision':job['revision'],'materials':r['materials']})
 for fmt in ['md','pdf','docx']:
  data=request(f'/api/jobs/{job["id"]}/export?format={fmt}&material=customer')
  (OUT/f'案例{key}-客服回复.{fmt}').write_bytes(data)
  if fmt=='pdf':
   assert data.startswith(b'%PDF-')
   with pdfplumber.open(io.BytesIO(data)) as pdf:
    text=''.join(p.extract_text() or '' for p in pdf.pages)
    assert '基金公告运营材料' in text and '已人工确认' in text
    if key=='C':assert '750' in text
  if fmt=='docx':
   assert data.startswith(b'PK')
   doc=Document(io.BytesIO(data));text=''.join(p.text for p in doc.paragraphs)
   assert '基金公告运营材料' in text and '已人工确认' in text
   assert any(p.style.name=='List Bullet' for p in doc.paragraphs)
 (OUT/f'案例{key}-实际结果.json').write_text(json.dumps(job,ensure_ascii=False,indent=2))
 rows.append({'case':key,'model':r['model_call']['model'],'seconds':job['elapsed_seconds'],'bullets':'passed','pdf':'passed','docx':'passed','md':'passed'})
 (OUT/'运行汇总.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
 print(key,'PASS',rows[-1],flush=True)
print('Three real model cases and nine exports passed.',flush=True)
