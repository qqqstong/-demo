/* Single-file case demonstration. No network or model calls. */
const offlineJobs=new Map(), offlineUploads=new Map();let offlineId=0;
const clone=x=>JSON.parse(JSON.stringify(x));
function offlineFail(message){throw Error(message);}
function money(value){return Number(value).toLocaleString('zh-CN',{minimumFractionDigits:2,maximumFractionDigits:2});}
function validNumber(value,label){if(value===''||value==null)return null;const n=Number(value);if(!Number.isFinite(n)||n<0||n>1e12)offlineFail(label+'必须是0至一万亿之间的有效数字。');return n;}
function dividend(shares,per,cash){
 const decimal=value=>{const t=String(value).split('.');return [BigInt(t.join('')),10n**BigInt((t[1]||'').length)];};
 const [a,as]=decimal(shares),[b,bs]=decimal(cash),[c,cs]=decimal(per);
 const numerator=a*b*cs*100n,denominator=as*bs*c;
 const cents=(numerator+denominator/2n)/denominator;
 return (cents/100n)+'.'+String(cents%100n).padStart(2,'0');
}
function offlineAnalyze(key,context){
 const r=clone(OFFLINE_CASES[key].result);r.context=clone(context);r.missing=[];
 if(key==='B'){
  const amount=validNumber(context.amount,'单次定投金额'),other=validNumber(context.other_amount,'同日其他申请金额'),limit=Number(r.facts.limit_amount.value);
  const effective=r.facts.effective_date.value.replace(/年|月/g,'-').replace('日','');
  let text,status='conditional';
  if(context.business_date&&new Date(context.business_date)<new Date(effective)){
   text='申请日期早于本次限制生效日，本次限制尚不适用；仍需核对申请当时的其他有效规则。';status='confirmed';
  }else if(amount===null){text='尚未提供本次申请金额，无法判断是否超限。';status='unknown';r.missing.push({text:'请补充单次定投金额。'});}
  else{
   const total=amount+(other??0);
   if(total>limit)text=`已知申请合计${money(total)}元，超过${money(limit)}元限额，管理人有权拒绝相关申请。公告未说明自动降额、部分成交或取消定投计划。`;
   else if(other===null){text=`已知申请${money(amount)}元未超过限额；同日其他适用申请未知，仍需核对完整累计金额。`;r.missing.push({text:'请核实同日其他适用申请；没有时填写0。'});}
   else text=`单日累计${money(total)}元未超过本次限额，恰好${money(limit)}元也不超限；这不代表保证申请成交。`;
   if(!context.business_date){text='若扣款申请发生在限制生效后，'+text;r.missing.push({text:'下一次扣款日期未提供，当前按限制生效后的情景判断。'});}else status='confirmed';
  }
  const claim=r.claims.find(c=>c.title==='用户定投影响');claim.text=text;claim.status=status;
 }
 if(key==='C'){
  const shares=validNumber(context.shares,'持有份额');const per=r.facts.per_shares.value,cash=r.facts.cash_per_unit.value;
  const amount=r.claims.find(c=>c.title==='本次分红金额');
  if(shares===null){amount.text='尚未提供享有本次权益的份额，暂不能计算分红金额。';amount.calculation=null;amount.status='unknown';r.missing.push({text:'请补充享有本次分红权益的份额。'});}
  else {const value=dividend(String(shares),per,cash);amount.text=`若这${shares.toLocaleString('zh-CN',{maximumFractionDigits:2})}份均享有本次分红权益，分红金额为${money(value)}元。`;amount.calculation=`${shares} ÷ ${per} × ${cash} = ${value} 元`;amount.status='conditional';}
  const method=r.claims.find(c=>c.title==='现金还是份额');
  if(context.change_status==='effective'&&['cash','reinvest'].includes(context.method)){method.text=`按运营提供的有效登记条件，本情景采用${context.method==='cash'?'现金分红':'红利再投资'}。这是人工补充的条件，尚未连接登记系统核验。`;method.status='conditional';}
  else r.missing.push({text:'请核实权益登记日前最后一次有效登记的分红方式和变更受理结果。'});
 }
 r.materials={customer:r.claims.map(c=>`- **${c.title}**：${c.text}`).join('\n'),app:r.materials.app,internal:r.claims.map(c=>`- **${c.title}**：${c.text}${c.calculation?' 计算：'+c.calculation:''}`).join('\n')};
 return r;
}
function offlineJob(upload,key,question,context,parent,feedback){
 const result=offlineAnalyze(key,context);result.filename=upload.filename;result.question=question;result.pages=clone(OFFLINE_CASES[key].pages);
 const count=parent?(parent.followup_count||0)+1:0;
 if(feedback){
  if(/简洁|短|精简/.test(feedback)){
   const short={A:['人员变化','离任原因','后续涨跌'],B:['限制规则','用户定投影响','恢复时间'],C:['本次分红金额','现金还是份额','再投资份额','发放时间']}[key];
   result.materials.customer=result.claims.filter(c=>short.includes(c.title)).map(c=>`- **${c.title}**：${c.text}`).join('\n');
  }
  if(/自然|语气|客户理解/.test(feedback))result.materials.customer=result.materials.customer.replace('仅凭变更申请的提交时间','您已提交申请，但仅凭提交时间').replace('无法判断基金后续涨跌','目前还无法判断基金后续涨跌');
  if(/关注|核实|解释/.test(feedback)&&result.missing.length)result.materials.customer+='\n- **需要核实**：'+result.missing.map(x=>x.text).join(' ');
 }
 const job={id:'offline-'+(++offlineId),revision:parent?parent.revision+1:1,approved:false,status:'completed',created_at:new Date().toLocaleString('zh-CN'),followup_count:count,upload_id:upload.id,document_id:key,result,events:[{step:'读取案例',message:'载入内置公告事实与原文。',status:'done'},{step:'判断与计算',message:'按案例规则结合输入条件完成本地计算。',status:'done'},{step:'整理材料',message:'生成要点式演示材料，等待人工核对。',status:'done'}],conversation:clone(parent?.conversation||[])};
 job.conversation.push({role:'user',text:feedback||question},{role:'assistant',text:result.materials.customer});offlineJobs.set(job.id,job);return clone(job);
}
async function offlineApi(path,data){
 if(path==='/api/samples')return Object.entries(OFFLINE_CASES).map(([id,x])=>({id,name:x.result.type_name,question:x.question}));
 if(path==='/api/upload'){
  const key=Object.keys(OFFLINE_CASES).find(k=>OFFLINE_CASES[k].pdf===data.data);
  if(!key)offlineFail('单文件演示版仅识别内置的三份样例PDF。请使用A／B／C案例；处理其他公告请打开完整本地版本。');
  const upload={id:'upload-'+(++offlineId),filename:data.filename,documents:[{id:key,name:OFFLINE_CASES[key].result.type_name,pages:OFFLINE_CASES[key].pages.length}]};offlineUploads.set(upload.id,upload);return clone(upload);
 }
 if(path==='/api/text'){
  const normal=t=>t.replace(/\s/g,'');const key=Object.keys(OFFLINE_CASES).find(k=>normal(OFFLINE_CASES[k].pages.map(p=>p.text).join(''))===normal(data.text));
  if(!key)offlineFail('离线版可载入内置案例的完整正文。处理其他公告请使用完整本地版本。');
  const upload={id:'upload-'+(++offlineId),filename:'粘贴正文',documents:[{id:key,name:OFFLINE_CASES[key].result.type_name,pages:OFFLINE_CASES[key].pages.length}]};offlineUploads.set(upload.id,upload);return clone(upload);
 }
 if(path==='/api/jobs')return offlineJob(offlineUploads.get(data.upload_id),data.document_id,data.question,data.context);
 const match=path.match(/^\/api\/jobs\/([^/]+)(?:\/(save|approve|followup))?$/);
 if(!match)offlineFail('此能力请在完整本地版本使用。');
 const job=offlineJobs.get(match[1]);if(!job)offlineFail('任务已失效，请重新载入案例。');if(!data)return clone(job);
 if(data.revision!==job.revision)offlineFail('版本已更新，请使用最新材料。');
 if(match[2]==='followup'){
  if(job.followup_count>=3)offlineFail('已完成3轮修改，仍可直接编辑文字。');
  if(!/简洁|短|精简|自然|语气|理解|关注|核实|解释|份额|金额|定投|扣款|日期/.test(data.feedback))offlineFail('离线版支持精简、语气、关注事项及金额／份额更正。其他要求请直接编辑文字，或使用完整本地版。');
  const context=clone(job.result.context),s=data.feedback;
  if(/改为|改成|更正|调整为|不是|实际|份额是|金额是|持有/.test(s)){
   const nums=[...s.matchAll(/(\d[\d,]*(?:\.\d+)?)\s*(万)?\s*份/g)];if(nums.length){const m=nums.at(-1);context.shares=String(Number(m[1].replaceAll(',',''))*(m[2]?10000:1));}
   const amounts=[...s.matchAll(/(\d[\d,]*(?:\.\d+)?)\s*(万)?\s*元/g)];if(amounts.length&&/金额|定投|申请|扣款/.test(s)){const m=amounts.at(-1);context.amount=String(Number(m[1].replaceAll(',',''))*(m[2]?10000:1));}
  }
  const date=s.match(/(\d{4})[年/-](\d{1,2})[月/-](\d{1,2})/);if(date&&/日期|扣款|交易日/.test(s))context.business_date=`${date[1]}-${date[2].padStart(2,'0')}-${date[3].padStart(2,'0')}`;
  return offlineJob(offlineUploads.get(job.upload_id),job.document_id,job.result.question,context,job,s);
 }
 if(data.materials&&JSON.stringify(data.materials)!==JSON.stringify(job.result.materials)){job.result.materials=clone(data.materials);job.revision++;job.approved=false;}
 if(match[2]==='approve')job.approved=true;
 return {revision:job.revision,approved:job.approved};
}
function offlineDownload(bytes,mime,name){const url=URL.createObjectURL(new Blob([bytes],{type:mime}));const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),10000);}
function zipStored(files){
 const enc=new TextEncoder(),chunks=[],central=[];let offset=0;
 const u16=(a,o,n)=>new DataView(a.buffer).setUint16(o,n,true),u32=(a,o,n)=>new DataView(a.buffer).setUint32(o,n,true);
 function crc32(a){let c=0xffffffff;for(const b of a){c^=b;for(let j=0;j<8;j++)c=(c>>>1)^((c&1)?0xedb88320:0);}return (c^0xffffffff)>>>0;}
 for(const [name,text] of Object.entries(files)){
  const n=enc.encode(name),b=enc.encode(text),crc=crc32(b),h=new Uint8Array(30+n.length);u32(h,0,0x04034b50);u16(h,4,20);u16(h,6,0x800);u32(h,14,crc);u32(h,18,b.length);u32(h,22,b.length);u16(h,26,n.length);h.set(n,30);chunks.push(h,b);
  const c=new Uint8Array(46+n.length);u32(c,0,0x02014b50);u16(c,4,20);u16(c,6,20);u16(c,8,0x800);u32(c,16,crc);u32(c,20,b.length);u32(c,24,b.length);u16(c,28,n.length);u32(c,42,offset);c.set(n,46);central.push(c);offset+=h.length+b.length;
 }
 const size=central.reduce((n,a)=>n+a.length,0),end=new Uint8Array(22);u32(end,0,0x06054b50);u16(end,8,central.length);u16(end,10,central.length);u32(end,12,size);u32(end,16,offset);return new Blob([...chunks,...central,end]);
}
function offlineWord(title,lines){
 const xml=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
 const p=(t,bold=false)=>`<w:p><w:pPr><w:spacing w:after="180" w:line="340"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:eastAsia="宋体"/>${bold?'<w:b/>':''}<w:sz w:val="24"/></w:rPr><w:t xml:space="preserve">${xml(t)}</w:t></w:r></w:p>`;
 return zipStored({'[Content_Types].xml':'<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>',
 '_rels/.rels':'<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>',
 'word/document.xml':`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>${p(title,true)}${lines.map(t=>p(t)).join('')}<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:bottom="1134" w:left="1247" w:right="1247"/></w:sectPr></w:body></w:document>`});
}
async function offlineExport(format){
 $('exportMenu').hidden=true;$('exportButton').setAttribute('aria-expanded','false');if(!await save(false))return;
 const job=state.job,r=job.result,title='基金公告运营材料 · '+labels[state.material],body=state.materials[state.material].replace(/\*\*(.*?)\*\*/g,'$1').replace(/^- /gm,'• '),meta=[r.facts.fund_name.value,(job.approved?'已人工确认':'未审核草稿')+' · 版本 '+job.revision,'离线案例演示 · 基于内置公告规则'];
 const lines=[...meta,'',...body.split('\n'),'',...(r.missing.length?['待核实事项',...r.missing.map(x=>'• '+x.text),'']:[]),'来源：'+r.filename];
 const name=`基金公告_${labels[state.material]}_v${job.revision}`;
 if(format==='md')offlineDownload('# '+title+'\n\n'+lines.join('\n\n'),'text/markdown;charset=utf-8',name+'.md');
 if(format==='docx')offlineDownload(offlineWord(title,lines),'application/vnd.openxmlformats-officedocument.wordprocessingml.document',name+'.docx');
 if(format==='pdf'){
  $('offlinePrint').innerHTML='<h1>'+esc(title)+'</h1>'+meta.map(t=>'<p>'+esc(t)+'</p>').join('')+readable(state.materials[state.material])+(r.missing.length?'<h2>待核实事项</h2><ul>'+r.missing.map(x=>'<li>'+esc(x.text)+'</li>').join('')+'</ul>':'')+'<p>来源：'+esc(r.filename)+'</p>';
  toast('在打印窗口中选择“存储为PDF”即可。');window.print();
 }
}
