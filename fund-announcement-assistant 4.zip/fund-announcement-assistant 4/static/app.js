'use strict';
const $ = id => document.getElementById(id);
const state = {upload:null, job:null, material:'customer', materials:{}, busy:false, samples:[], editing:false};
const esc = value => String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const statusNames = {confirmed:'可确认',conditional:'有条件',unknown:'待核实'};
const labels = {customer:'客服回复',app:'App提示',internal:'内部要点'};
async function api(path, body){
  const response = await fetch(path,body===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  const result = await response.json();
  if(!response.ok)throw Error(result.error||'请求失败');
  return result;
}
function toast(message){
  $('toast').textContent=message;$('toast').hidden=false;clearTimeout(toast.timer);
  toast.timer=setTimeout(()=>$('toast').hidden=true,2800);
}
function error(message){$('inputError').textContent=message||'';$('inputError').hidden=!message;}
function busy(on){
  state.busy=on;$('runButton').disabled=on||!state.upload;
  document.querySelectorAll('.sample,#resetButton,#pasteButton,#fileInput,#documentSelect,#question,#amount,#otherAmount,#businessDate,#shares,#method,#changeStatus,#pasteText,#feedbackInput,#editButton,#saveButton,#approveButton,#exportButton,#materialEditor,[data-suggestion],[data-export]').forEach(x=>x.disabled=on);
  $('feedbackButton').disabled=on||(state.job?.followup_count||0)>=3;
  $('runButton').firstElementChild.textContent=on?'正在整理，请稍候…':'开始分析并生成材料';
}
function tab(name){
  document.querySelectorAll('.tab').forEach(x=>{const selected=x.dataset.tab===name;x.classList.toggle('active',selected);x.setAttribute('aria-selected',String(selected));});
  document.querySelectorAll('.tab-content').forEach(x=>x.hidden=x.id!=='tab-'+name);
}
function context(){return {amount:$('amount').value,other_amount:$('otherAmount').value,business_date:$('businessDate').value,shares:$('shares').value,method:$('method').value,change_status:$('changeStatus').value};}
function resetContext(){['amount','otherAmount','businessDate','shares'].forEach(x=>$(x).value='');$('method').value='unknown';$('changeStatus').value='unknown';}
function selectDocument(fillQuestion=false){
  const type=$('documentSelect').value;
  $('scenarioB').hidden=type!=='B';$('scenarioC').hidden=type!=='C';
  if(fillQuestion){
    resetContext();$('question').value=state.samples.find(x=>x.id===type)?.question||'请帮我整理公告，并准备客服与App运营材料。';
    if(type==='B')$('amount').value='20000';if(type==='C')$('shares').value='25000';
  }
}
async function uploadFile(file,sample){
  if(state.busy)return;error('');if(file.size>10_000_000)return error('文件不能超过10MB。');
  busy(true);$('dropTitle').textContent='正在读取文件…';
  try{
    const bytes=new Uint8Array(await file.arrayBuffer());let binary='';
    for(let i=0;i<bytes.length;i+=32768)binary+=String.fromCharCode(...bytes.subarray(i,i+32768));
    setUpload(await api('/api/upload',{filename:file.name,data:btoa(binary)}),sample);toast('公告已载入，可开始分析');
  }catch(e){error(e.message);}finally{busy(false);$('dropTitle').textContent='上传或更换基金公告';}
}
function setUpload(result,sample){
  state.upload=result;state.job=null;state.materials={};resetContext();$('fileInfo').textContent='✓ '+result.filename;$('fileInfo').hidden=false;
  $('documentSelect').innerHTML=result.documents.map(x=>`<option value="${esc(x.id)}">公告 ${esc(x.id)} · ${esc(x.name)}（${x.pages}页）</option>`).join('');
  if(sample&&result.documents.some(x=>x.id===sample))$('documentSelect').value=sample;
  $('documentField').hidden=result.documents.length<2;
  document.querySelectorAll('.sample').forEach(x=>x.classList.toggle('selected',x.dataset.sample===sample));
  selectDocument(true);$('resultArea').hidden=true;$('progressPanel').hidden=true;$('emptyState').hidden=false;$('feedbackInput').value='';badge('等待分析');
}
function badge(text,approved=false){$('reviewBadge').textContent=text;$('reviewBadge').classList.toggle('approved',approved);}
function displayEvent(event){
  if(event.step==='模型生成')return {step:'整理材料',message:event.status==='error'?'自动整理未完成，已保留基础草稿。':event.status==='running'?'正在调整表达与要点…':'材料已整理完成。'};
  if(event.step==='规则与计算')return {step:'判断与计算',message:'已结合公告规则完成影响判断和必要计算。'};
  if(event.step==='提取与检索')return {step:'核对公告',message:'已提取关键事实并保留原文依据。'};
  return event;
}
async function run(){
  if(!state.upload)return error('请先上传公告。');if(!$('question').value.trim())return error('请输入处理诉求。');
  error('');busy(true);$('emptyState').hidden=true;$('resultArea').hidden=true;$('progressPanel').hidden=false;$('progressEvents').innerHTML='';$('progressTitle').textContent='正在分析公告';$('progressDesc').textContent='正在创建任务…';badge('处理中');
  try{
    const job=await api('/api/jobs',{upload_id:state.upload.id,document_id:$('documentSelect').value,question:$('question').value,context:context()});
    await poll(job.id);
  }catch(e){error(e.message);$('progressPanel').hidden=true;$('emptyState').hidden=false;badge('处理未完成');}
  finally{busy(false);}
}
async function poll(id,followup=false){
  const job=await api('/api/jobs/'+id);
  const events=job.events.map(displayEvent);
  const step=events.at(-1)?.step||'准备处理';
  if(followup)$('feedbackStatus').textContent='正在根据反馈更新材料 · '+step;
  else{
    $('progressDesc').textContent=step;
    $('progressEvents').innerHTML=events.map(e=>`<li>${esc(e.step)} · ${esc(e.message)}</li>`).join('');
  }
  if(job.status==='failed')throw Error(job.error||'处理失败');
  if(job.status==='completed'){render(job,followup);return;}
  await new Promise(resolve=>setTimeout(resolve,1100));return poll(id,followup);
}
function inline(text){return esc(text).replace(/\*\*(.*?)\*\*/g,'<strong>$1</strong>');}
function readable(text){
  let output='',inList=false;
  for(const line of String(text||'').split('\n')){
    if(!line.trim())continue;
    const bullet=line.match(/^\s*[-*•]\s+(.+)$/);
    if(bullet){if(!inList){output+='<ul>';inList=true;}output+='<li>'+inline(bullet[1])+'</li>';}
    else{if(inList){output+='</ul>';inList=false;}output+='<p>'+inline(line.replace(/^#{1,4}\s+/,''))+'</p>';}
  }
  return output+(inList?'</ul>':'');
}
function render(job,followup=false){
  const selected=followup?state.material:'customer';state.job=job;const r=job.result;state.materials={...r.materials};state.material=selected;
  state.editing=false;$('materialEditor').hidden=true;$('materialPreview').hidden=false;$('editButton').textContent='编辑文字';
  $('progressPanel').hidden=true;$('emptyState').hidden=true;$('resultArea').hidden=false;badge(job.approved?'已人工确认':'待人工审核',job.approved);
  $('resultType').textContent='公告 '+r.type+' / '+r.type_name;$('resultFund').textContent=r.facts.fund_name?.value||r.type_name;
  updateMeta();
  $('engineWarning').hidden=!r.model_error;$('engineWarning').textContent=r.model_error?'本次自动润色未完成，当前保留基于公告的基础材料。可以继续修改或直接编辑。':'';
  const factKeys=['fund_code','publication_date','effective_date','remaining_manager','distribution','record_date','pay_date','limit_amount'];
  $('factsGrid').innerHTML=factKeys.filter(k=>r.facts[k]).map(k=>`<div class="fact"><span>${esc(r.facts[k].label)}</span><strong>${esc(r.facts[k].value)}</strong></div>`).join('');
  $('claimList').innerHTML=r.claims.map(c=>`<article class="claim"><div class="claim-top"><h4>${esc(c.title)}</h4><span class="status-label ${esc(c.status)}">${statusNames[c.status]||'待核实'}</span></div><p>${esc(c.text)}</p>${c.calculation?`<div class="formula">${esc(c.calculation)}</div>`:''}<div>${c.evidence_ids.map(e=>`<button class="citation" data-evidence="${esc(e)}">[${esc(e)}] 查看依据 ↗</button>`).join('')}</div></article>`).join('');
  $('missingBox').hidden=!r.missing.length;$('missingList').innerHTML=r.missing.map(x=>`<li>${esc(x.text)}</li>`).join('');$('sourceCount').textContent=r.evidence.length;
  const isText=r.filename.includes('粘贴正文');
  $('evidenceList').innerHTML=r.evidence.map(e=>`<article class="evidence-card" id="evidence-${esc(e.id)}"><strong>[${esc(e.id)}] ${esc(e.label)}</strong><span>${isText?'正文段落':'本次文件第 '+e.page+' 页'}</span><blockquote>${esc(e.quote)}</blockquote></article>`).join('');
  $('fullText').innerHTML=r.pages.map(p=>`<h4>${isText?'正文':'第 '+p.page+' 页'}</h4><pre>${esc(p.text)}</pre>`).join('');$('pdfLink').hidden=isText;$('pdfLink').href='/api/files/'+state.upload.id;
  $('traceList').innerHTML=job.events.map((raw,i)=>{const e=displayEvent(raw);return `<div class="trace-item ${esc(raw.status)}"><span class="trace-index">${i+1}</span><div><strong>${esc(e.step)}</strong><p>${esc(e.message)}</p></div></div>`;}).join('');
  $('toolList').innerHTML='';$('taskMeta').textContent=`材料版本 ${job.revision} · ${job.created_at}`;
  $('materialNotice').textContent=followup?'材料已根据反馈更新，请核对后重新确认。':'请核对要点及必要条件后确认。';
  $('materialEditor').value=state.materials[selected];selectMaterial(selected);tab(followup?'materials':'analysis');
  $('claimList').querySelectorAll('[data-evidence]').forEach(x=>x.onclick=()=>showEvidence(x.dataset.evidence));
  const count=job.followup_count||0;$('roundLabel').textContent=`已修改 ${count} / 3 轮`;
  $('feedbackInput').value='';$('feedbackStatus').textContent=count>=3?'已完成3轮反馈，仍可直接编辑文字。':'补充信息或提出新的修改要求。';
  $('conversationList').innerHTML=(job.conversation||[]).map(m=>m.role==='user'?`<div class="chat-message user"><span>你</span><p>${esc(m.text)}</p></div>`:`<div class="chat-message assistant"><span>助手</span><details><summary>材料已生成，点击查看本轮回复</summary><div class="chat-reply">${readable(m.text)}</div></details></div>`).join('');
  if(followup){
    const c=r.context;for(const [id,key] of [['amount','amount'],['otherAmount','other_amount'],['businessDate','business_date'],['shares','shares']])$(id).value=c[key]||'';
    toast('已根据反馈更新材料');
  }
}
function updateMeta(){const job=state.job;$('resultMeta').textContent=`${job.result.filename} · 版本 ${job.revision}`;}
function showEvidence(id){tab('sources');const e=$('evidence-'+id);document.querySelectorAll('.evidence-card').forEach(x=>x.classList.remove('highlight'));e?.classList.add('highlight');e?.scrollIntoView({behavior:'smooth',block:'center'});}
function syncEditor(){if(state.job&&state.editing)state.materials[state.material]=$('materialEditor').value;}
function selectMaterial(key){
  syncEditor();state.material=key;$('materialEditor').value=state.materials[key]||'';$('materialPreview').innerHTML=readable(state.materials[key]);
  document.querySelectorAll('[data-material]').forEach(x=>x.classList.toggle('active',x.dataset.material===key));
}
async function save(approve=false){
  if(!state.job)return;syncEditor();
  try{
    const out=await api('/api/jobs/'+state.job.id+(approve?'/approve':'/save'),{revision:state.job.revision,materials:state.materials});
    state.job.revision=out.revision;state.job.approved=out.approved;updateMeta();badge(out.approved?'已人工确认':'待人工审核',out.approved);
    $('materialNotice').textContent=out.approved?`版本 ${out.revision} 已人工确认，可导出使用。`:`草稿已保存为版本 ${out.revision}，需要人工审核。`;
    toast(approve?'当前材料已确认':out.approved?'已确认版本已保存':'草稿已保存');return true;
  }catch(e){toast(e.message);return false;}
}
async function followup(){
  if(state.busy||!state.job)return;
  const feedback=$('feedbackInput').value.trim();if(!feedback)return toast('请先输入修改要求或补充信息。');
  syncEditor();busy(true);$('feedbackStatus').textContent='正在根据反馈更新材料…';
  try{
    const job=await api('/api/jobs/'+state.job.id+'/followup',{revision:state.job.revision,feedback,materials:state.materials});
    await poll(job.id,true);
  }catch(e){$('feedbackStatus').textContent=e.message;toast(e.message);}finally{busy(false);}
}
async function exportFile(format){
  $('exportMenu').hidden=true;$('exportButton').setAttribute('aria-expanded','false');
  if(!await save(false))return;
  try{
    const response=await fetch(`/api/jobs/${state.job.id}/export?format=${format}&material=${state.material}`);
    if(!response.ok)throw Error((await response.json()).error||'导出失败');
    const url=URL.createObjectURL(await response.blob()),link=document.createElement('a');
    link.href=url;link.download=`基金公告_${labels[state.material]}_v${state.job.revision}.${format}`;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),10000);toast('文件已导出');
  }catch(e){toast(e.message);}
}
$('fileInput').onchange=e=>{if(e.target.files[0])uploadFile(e.target.files[0]);};
$('dropzone').ondragover=e=>{e.preventDefault();$('dropzone').classList.add('drag');};$('dropzone').ondragleave=()=>$('dropzone').classList.remove('drag');$('dropzone').ondrop=e=>{e.preventDefault();$('dropzone').classList.remove('drag');if(e.dataTransfer.files[0])uploadFile(e.dataTransfer.files[0]);};
document.querySelectorAll('[data-sample]').forEach(button=>button.onclick=async()=>{try{const key=button.dataset.sample,response=await fetch('/samples/'+key+'.pdf');if(!response.ok)throw Error('样例文件读取失败');await uploadFile(new File([await response.blob()],`题目公告${key}.pdf`,{type:'application/pdf'}),key);}catch(e){error(e.message);}});
$('pasteButton').onclick=async()=>{try{error('');busy(true);setUpload(await api('/api/text',{text:$('pasteText').value}));}catch(e){error(e.message);}finally{busy(false);}};
$('documentSelect').onchange=()=>selectDocument(true);$('runButton').onclick=run;
document.querySelectorAll('[data-tab]').forEach(x=>x.onclick=()=>tab(x.dataset.tab));document.querySelectorAll('[data-material]').forEach(x=>x.onclick=()=>selectMaterial(x.dataset.material));
$('goMaterials').onclick=()=>tab('materials');$('saveButton').onclick=()=>save();$('approveButton').onclick=()=>save(true);
$('editButton').onclick=()=>{syncEditor();state.editing=!state.editing;$('materialEditor').value=state.materials[state.material];$('materialPreview').innerHTML=readable(state.materials[state.material]);$('materialEditor').hidden=!state.editing;$('materialPreview').hidden=state.editing;$('editButton').textContent=state.editing?'完成编辑':'编辑文字';};
$('materialEditor').oninput=()=>{badge('已修改 · 待确认');$('materialNotice').textContent='有未保存修改，请保存或重新确认。';};
$('copyButton').onclick=async()=>{syncEditor();try{await navigator.clipboard.writeText((state.materials[state.material]||'').replace(/\*\*(.*?)\*\*/g,'$1').replace(/^- /gm,'• '));toast('当前材料已复制');}catch(e){toast('浏览器未允许复制，请选择文本后复制。');}};
$('exportButton').onclick=()=>{const menu=$('exportMenu');menu.hidden=!menu.hidden;$('exportButton').setAttribute('aria-expanded',String(!menu.hidden));};
document.querySelectorAll('[data-export]').forEach(x=>x.onclick=()=>exportFile(x.dataset.export));
document.addEventListener('click',e=>{if(!e.target.closest('.export-control')){$('exportMenu').hidden=true;$('exportButton').setAttribute('aria-expanded','false');}});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){$('exportMenu').hidden=true;$('exportButton').setAttribute('aria-expanded','false');}});
$('feedbackButton').onclick=followup;document.querySelectorAll('[data-suggestion]').forEach(x=>x.onclick=()=>{$('feedbackInput').value=x.dataset.suggestion;$('feedbackInput').focus();});
$('feedbackInput').onkeydown=e=>{if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){e.preventDefault();followup();}};
$('resetButton').onclick=()=>{state.upload=null;state.job=null;$('fileInput').value='';$('question').value='';$('fileInfo').hidden=true;$('documentField').hidden=true;$('scenarioB').hidden=true;$('scenarioC').hidden=true;$('resultArea').hidden=true;$('progressPanel').hidden=true;$('emptyState').hidden=false;$('dropTitle').textContent='上传基金公告';document.querySelectorAll('.sample').forEach(x=>x.classList.remove('selected'));resetContext();error('');busy(false);badge('等待公告');};
$('helpButton').onclick=()=>$('helpDialog').showModal();$('closeHelp').onclick=()=>$('helpDialog').close();
(async()=>{try{state.samples=await api('/api/samples');}catch(e){error('服务未连接，请启动本地服务后刷新页面。');}})();
