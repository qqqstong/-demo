#!/usr/bin/env python3
"""Loopback-only HTML demo. No framework required; PDFs parsed by pdfplumber."""
import base64
import hashlib
import json
import mimetypes
import os
import re
import shutil
import copy
import secrets
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone, timedelta
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

from engine import ROOT, QUESTIONS, TYPES, parse_pdf, split_documents, analyze, model_materials
from exports import render_export

DATA = ROOT / '.data'
DATA.mkdir(exist_ok=True)
UPLOADS, JOBS = {}, {}
LOCK = threading.RLock()
POOL = ThreadPoolExecutor(max_workers=1)


def now():
    return datetime.now(timezone(timedelta(hours=8))).isoformat(timespec='seconds')


def persist(job):
    (DATA / (job['id'] + '.json')).write_text(json.dumps(job, ensure_ascii=False, indent=2))


def event(job, step, message, status='done'):
    with LOCK:
        job['events'].append({'at': now(), 'step': step, 'message': message, 'status': status})
        job['stage'] = step
        persist(job)


def process(job, upload, kind, question, context, provider, feedback='', previous_materials=None, conversation=None):
    try:
        job['status'] = 'running'
        event(job, '解析公告', f"读取 {upload['filename']}，选择公告{kind}；已排除考试任务说明。")
        pages = upload['documents'][kind]
        event(job, '提取与检索', '从当前文件提取字段，保留页码与原句；未从测试答案生成结论。')
        result = analyze(pages, kind, question, context)
        event(job, '规则与计算', f"完成{len(result['tools'])}个业务工具，获得{len(result['evidence'])}条证据。")
        result['pages'] = pages
        result['filename'] = upload['filename']
        result['question'] = question
        result['context'] = context
        result['file_hash'] = upload['sha256']
        job['result'] = result
        if provider != 'rules':
            event(job, '模型生成', '正在真实请求模型生成材料；超时将明确保留规则结果。', 'running')
            try:
                materials, meta = model_materials(result, question, provider, feedback, previous_materials, conversation)
                result['materials'] = materials
                result['model_call'] = meta
                result['engine'] = f"{meta['model']}＋公告解析与规则计算"
                event(job, '模型生成', f"模型真实返回：{meta['model']}，耗时{meta['elapsed_seconds']}秒。")
            except Exception as exc:
                result['model_error'] = str(exc)
                event(job, '模型生成', str(exc), 'error')
        event(job, '结果校验', '数字经规则工具计算，引用与正文对应；材料保持待人工审核。')
        job['conversation'] = list(conversation or [])
        job['conversation'].append({'role': 'user', 'text': feedback or question})
        job['conversation'].append({'role': 'assistant', 'text': result['materials']['customer']})
        job['status'] = 'completed'
        job['finished_at'] = now()
        job['elapsed_seconds'] = round(time.monotonic() - job.pop('_started'), 2)
        persist(job)
    except Exception as exc:
        job['status'] = 'failed'; job['error'] = str(exc)
        event(job, '处理失败', str(exc), 'error')


def default_provider():
    configured = os.environ.get('FUND_PROVIDER')
    if configured in ('rules', 'codex', 'kimi'):
        return configured
    return 'kimi' if os.environ.get('MOONSHOT_API_KEY') else 'codex' if shutil.which('codex') else 'rules'


def feedback_context(context, feedback):
    updated = dict(context)
    # Only explicit corrections update numerical business conditions.
    if re.search(r'改为|改成|调整为|更正|不是|实际|持有份额|份额是|金额是|持有.*份', feedback):
        shares = list(re.finditer(r'(\d[\d,]*(?:\.\d+)?)\s*(万)?\s*份', feedback))
        if shares:
            m = shares[-1]
            updated['shares'] = str(__import__('decimal').Decimal(m[1].replace(',', '')) * (10000 if m[2] else 1))
        amounts = list(re.finditer(r'(\d[\d,]*(?:\.\d+)?)\s*(万)?\s*元', feedback))
        if amounts and re.search(r'定投|申请金额|金额|扣款', feedback):
            m = amounts[-1]
            updated['amount'] = str(__import__('decimal').Decimal(m[1].replace(',', '')) * (10000 if m[2] else 1))
    if re.search(r'扣款|申请日期|交易日', feedback):
        date = re.search(r'(20\d{2})[年/-](\d{1,2})[月/-](\d{1,2})日?', feedback)
        if date:
            updated['business_date'] = f'{date[1]}-{int(date[2]):02d}-{int(date[3]):02d}'
    return updated


def markdown(job):
    r = job['result']
    parts = ['# 基金公告运营材料', '', f"状态：{'已人工确认' if job['approved'] else '未审核草稿'} · 版本{job['revision']}",
             f"实际引擎：{r['engine']}", f"文件：{r['filename']} · SHA256 {r['file_hash']}",
             f"任务：{job['id']} · 运行时间：{job['created_at']}", '', '## 用户问题', r['question'], '', '## 结论与计算']
    for c in r['claims']:
        parts += [f"### {c['title']}", c['text']]
        if c['calculation']: parts += [c['calculation']]
        parts += ['依据：'+', '.join(c['evidence_ids']), '']
    for k, label in [('customer', '客服回复'), ('app', 'App提示'), ('internal', '内部要点')]:
        parts += ['## '+label, r['materials'][k], '']
    parts += ['## 待核实事项'] + [x['text'] for x in r['missing']]
    parts += ['', '## 原文证据']
    for e in r['evidence']:
        location = "粘贴正文段落" if "粘贴正文" in r["filename"] else f"本次文件第{e['page']}页"
        parts += [f"[{e['id']}] {location}：{e['quote']}"]
    parts += ['', '## 说明', '题目产品、人物与数据均为虚构。规则模式为实际解析与计算，非模型生成；模型模式如失败会明确披露。',
              '样例PDF为考试材料公告正文摘录重排，文件页码与原始考试页码可能不同。未连接账户、登记、交易或发布系统。']
    return '\n\n'.join(parts)


class Handler(BaseHTTPRequestHandler):
    server_version = 'FundDemo/1.0'

    def log_message(self, fmt, *args):
        if '/api/jobs/' not in self.path:
            super().log_message(fmt, *args)

    def session(self):
        c = SimpleCookie()
        try: c.load(self.headers.get('Cookie', ''))
        except Exception: pass
        v = c.get('fund_session')
        if v and len(v.value) == 48:
            return v.value, False
        return secrets.token_hex(24), True

    def send(self, data, status=200, content_type='application/json; charset=utf-8', extra=None):
        if isinstance(data, (dict, list)): data = json.dumps(data, ensure_ascii=False).encode()
        elif isinstance(data, str): data = data.encode()
        session, fresh = self.session()
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; frame-src 'self' blob:; object-src 'none'; base-uri 'none'")
        if fresh: self.send_header('Set-Cookie', f'fund_session={session}; HttpOnly; SameSite=Strict; Path=/')
        for key, value in (extra or {}).items(): self.send_header(key, value)
        self.end_headers(); self.wfile.write(data)

    def read_json(self):
        host = self.headers.get('Host', '')
        if host not in (f'localhost:{self.server.server_port}', f'127.0.0.1:{self.server.server_port}'):
            raise ValueError('仅允许本机访问。')
        origin = self.headers.get('Origin')
        if origin and origin not in ('http://'+host,):
            raise ValueError('请求来源不匹配。')
        if not self.headers.get('Content-Type', '').startswith('application/json'):
            raise ValueError('请使用JSON请求。')
        length = int(self.headers.get('Content-Length', 0))
        if not 0 < length <= 16_000_000: raise ValueError('请求为空或文件过大（最大10MB）。')
        return json.loads(self.rfile.read(length))

    def own(self, collection, key):
        obj = collection.get(key)
        if not obj or obj['owner'] != self.session()[0]:
            raise ValueError('任务不存在或不属于当前会话。')
        return obj

    def do_GET(self):
        try:
            path = urlparse(self.path).path
            if path == '/api/health':
                return self.send({'ok': True, 'engines': {'rules': True, 'codex': bool(__import__('shutil').which('codex')), 'kimi': bool(os.environ.get('MOONSHOT_API_KEY'))}, 'default_engine': default_provider()})
            if path == '/api/samples':
                return self.send([{'id': k, 'name': TYPES[k], 'question': QUESTIONS[k], 'url': f'/samples/{k}.pdf'} for k in TYPES])
            if path.startswith('/api/jobs/'):
                segments = path.split('/')
                job = self.own(JOBS, segments[3])
                if len(segments) == 5 and segments[4] == 'export':
                    if not job.get('result'): raise ValueError('任务尚未完成。')
                    if job['status'] != 'completed':
                        raise ValueError('请等待材料处理完成后导出。')
                    params = parse_qs(urlparse(self.path).query)
                    fmt = params.get('format', ['md'])[0]
                    audience = params.get('material', ['all'])[0]
                    if not params:
                        content, mime = markdown(job), 'text/markdown; charset=utf-8'
                    else:
                        content, mime = render_export(job, fmt, audience)
                    return self.send(content, content_type=mime, extra={'Content-Disposition': f'attachment; filename="fund-material-{job["id"][:8]}.{fmt}"'})
                public = {k:v for k,v in job.items() if k not in ('owner', '_started')}
                return self.send(public)
            if path.startswith('/api/files/'):
                upload = self.own(UPLOADS, path.split('/')[3])
                return self.send(upload['bytes'], content_type='application/pdf')
            if re_sample(path):
                return self.send((ROOT/'samples'/f'公告{path[-5]}.pdf').read_bytes(), content_type='application/pdf', extra={'Content-Disposition': f'attachment; filename="notice-{path[-5]}.pdf"'})
            files = {'/': 'index.html', '/index.html': 'index.html', '/app.js': 'app.js', '/style.css': 'style.css'}
            if path not in files: return self.send({'error': 'Not found'}, 404)
            f = ROOT/'static'/files[path]
            return self.send(f.read_bytes(), content_type=mimetypes.guess_type(str(f))[0]+'; charset=utf-8')
        except Exception as exc:
            self.send({'error': str(exc)}, 400)

    def do_POST(self):
        try:
            data = self.read_json()
            path = urlparse(self.path).path
            owner = self.session()[0]
            if path == '/api/upload':
                filename = Path(str(data.get('filename', '公告.pdf'))).name
                raw = base64.b64decode(data.get('data', ''), validate=True)
                if len(raw) > 10_000_000: raise ValueError('PDF不能超过10MB。')
                if not raw.startswith(b'%PDF-'): raise ValueError('请上传PDF文件。')
                pages = parse_pdf(raw)
                docs = split_documents(pages)
                ident = secrets.token_hex(12)
                UPLOADS[ident] = {'id': ident, 'owner': owner, 'filename': filename, 'bytes': raw, 'documents': docs,
                                  'sha256': hashlib.sha256(raw).hexdigest()}
                return self.send({'id': ident, 'filename': filename, 'sha256': UPLOADS[ident]['sha256'],
                                  'documents': [{'id': k, 'name': TYPES.get(k, '暂不支持的公告'), 'pages': len(v)} for k,v in docs.items()]})
            if path == '/api/text':
                text = str(data.get('text', ''))
                if not 50 <= len(text) <= 65000: raise ValueError('请输入50至65000字的公告正文。')
                docs = split_documents([{'page': 1, 'text': __import__('engine').normalize(text)}])
                ident = secrets.token_hex(12)
                UPLOADS[ident] = {'id': ident, 'owner': owner, 'filename': '粘贴正文（无PDF页码）', 'bytes': b'', 'documents': docs,
                                  'sha256': hashlib.sha256(text.encode()).hexdigest()}
                return self.send({'id': ident, 'filename': UPLOADS[ident]['filename'], 'documents': [{'id': k, 'name': TYPES.get(k, '暂不支持的公告'), 'pages':len(v)} for k,v in docs.items()]})
            if path == '/api/jobs':
                upload = self.own(UPLOADS, data.get('upload_id'))
                kind = data.get('document_id')
                if kind not in upload['documents']: raise ValueError('请选择要处理的公告。')
                provider = data.get('engine', default_provider())
                if provider not in ('rules', 'codex', 'kimi'): raise ValueError('未知模型引擎。')
                question = str(data.get('question', '')).strip()
                if not question or len(question)>4000: raise ValueError('请输入1至4000字的问题。')
                context = data.get('context', {})
                if not isinstance(context, dict): raise ValueError('用户条件格式错误。')
                if context.get('business_date'): __import__('engine').parse_date(context['business_date'])
                for f in ['amount','other_amount','shares']:
                    __import__('engine').number(context.get(f), f)
                ident = secrets.token_hex(12)
                job = {'id': ident, 'owner': owner, 'created_at': now(), '_started': time.monotonic(),
                       'status': 'queued', 'stage': '等待处理', 'events': [], 'revision': 1, 'approved': False,
                       'upload_id': upload['id'], 'document_id': kind, 'provider': provider, 'followup_count': 0}
                JOBS[ident] = job
                POOL.submit(process, job, upload, kind, question, context, provider)
                return self.send({'id': ident}, 202)
            if path.startswith('/api/jobs/'):
                job = self.own(JOBS, path.split('/')[3])
                if job['status'] != 'completed': raise ValueError('请等待任务完成。')
                if int(data.get('revision', -1)) != job['revision']: raise ValueError('版本已变化，请刷新后重试。')
                materials = data.get('materials')
                if path.endswith('/followup'):
                    feedback = str(data.get('feedback', '')).strip()
                    if not feedback or len(feedback) > 2000:
                        raise ValueError('请输入1至2000字的修改要求或补充信息。')
                    if job.get('followup_count', 0) >= 3:
                        raise ValueError('本次已完成3轮继续修改，仍可直接编辑文字或新建任务。')
                    if job.get('pending_followup'):
                        pending = JOBS.get(job['pending_followup'], {})
                        if pending.get('status') in ('queued', 'running', 'completed'):
                            raise ValueError('该版本已有后续回复，请使用最新版本继续。')
                    if materials is not None and (set(materials) != {'customer','app','internal'} or not all(isinstance(v,str) and len(v)<15000 for v in materials.values())):
                        raise ValueError('材料格式错误。')
                    upload = self.own(UPLOADS, job['upload_id'])
                    context = feedback_context(job['result']['context'], feedback)
                    for field in ('amount', 'other_amount', 'shares'):
                        __import__('engine').number(context.get(field), field)
                    if context.get('business_date'):
                        __import__('engine').parse_date(context['business_date'])
                    ident = secrets.token_hex(12)
                    child = {'id': ident, 'owner': owner, 'created_at': now(), '_started': time.monotonic(),
                             'status': 'queued', 'stage': '根据反馈更新材料', 'events': [],
                             'revision': job['revision']+1, 'approved': False, 'upload_id': job['upload_id'],
                             'document_id': job['document_id'], 'provider': job['provider'],
                             'parent_id': job['id'], 'followup_count': job.get('followup_count',0)+1}
                    JOBS[ident] = child
                    job['pending_followup'] = ident
                    persist(job)
                    POOL.submit(process, child, upload, job['document_id'], job['result']['question'], context,
                                job['provider'], feedback, copy.deepcopy(materials or job['result']['materials']),
                                copy.deepcopy(job.get('conversation', [])))
                    return self.send({'id': ident}, 202)
                if materials is not None:
                    if set(materials) != {'customer','app','internal'} or not all(isinstance(v,str) and len(v)<15000 for v in materials.values()): raise ValueError('材料格式错误。')
                    if materials != job['result']['materials']:
                        job['result']['materials'] = materials; job['revision'] += 1; job['approved'] = False
                        job['result']['manually_edited'] = True
                if path.endswith('/approve'):
                    job['approved'] = True; job['approved_at'] = now()
                persist(job)
                return self.send({'revision': job['revision'], 'approved': job['approved']})
            return self.send({'error':'Not found'},404)
        except Exception as exc:
            self.send({'error':str(exc)},400)


def re_sample(path):
    return path in ['/samples/A.pdf','/samples/B.pdf','/samples/C.pdf']


if __name__ == '__main__':
    port = int(os.environ.get('PORT', '8765'))
    server = ThreadingHTTPServer(('127.0.0.1', port), Handler)
    print(f'基金公告运营助手：http://127.0.0.1:{port}', flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close(); POOL.shutdown(wait=False, cancel_futures=True)
