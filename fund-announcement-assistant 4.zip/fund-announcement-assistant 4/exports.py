"""Readable material formatting and real Markdown, PDF and DOCX downloads."""
import io
import re
from html import escape

LABELS = {'customer': '客服回复', 'app': 'App提示', 'internal': '内部要点'}


def plain(text):
    return re.sub(r'\*\*(.*?)\*\*', r'\1', text)


def bullet_text(text):
    """Preserve existing bullets; split plain Chinese prose into readable items."""
    lines = []
    for paragraph in str(text).strip().splitlines():
        paragraph = paragraph.strip()
        if not paragraph:
            continue
        if re.match(r'^[-*•]\s+', paragraph):
            lines.append('- ' + re.sub(r'^[-*•]\s+', '', paragraph))
        else:
            paragraph = re.sub(r'^#{1,4}\s+', '', paragraph)
            lines.extend('- ' + part.strip() for part in re.split(r'(?<=[。！？])\s*', paragraph) if part.strip())
    merged = []
    i = 0
    while i < len(lines):
        if re.fullmatch(r'- \*\*[^*]+\*\*[:：]?', lines[i]) and i + 1 < len(lines):
            merged.append(lines[i].rstrip('：:') + '：' + re.sub(r'^- ', '', lines[i+1]))
            i += 2
        else:
            merged.append(lines[i])
            i += 1
    return '\n'.join(merged)


def export_sections(job, material):
    result = job['result']
    selected = list(LABELS) if material == 'all' else [material]
    if any(k not in LABELS for k in selected):
        raise ValueError('请选择客服回复、App提示或内部要点。')
    status = '已人工确认' if job['approved'] else '未审核草稿'
    intro = f"{result['facts']['fund_name']['value']}\n{status} · 版本 {job['revision']}"
    sections = []
    for key in selected:
        sections.append((LABELS[key], result['materials'][key]))
    if result['missing']:
        sections.append(('待核实事项', '\n'.join('- '+m['text'] for m in result['missing'])))
    pages = '、'.join(str(p) for p in sorted(set(e['page'] for e in result['evidence'])))
    source = f"公告来源：{result['filename']}"
    if '粘贴正文' not in result['filename']:
        source += f'；本次文件第{pages}页。'
    sections.append(('参考依据', source))
    return '基金公告运营材料', intro, sections


def render_export(job, fmt='md', material='customer'):
    title, intro, sections = export_sections(job, material)
    if fmt == 'md':
        body = '\n\n'.join([f'# {title}', intro] + [f'## {name}\n\n{text}' for name, text in sections])
        return body.encode(), 'text/markdown; charset=utf-8'
    if fmt == 'docx':
        return docx_bytes(title, intro, sections), 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    if fmt == 'pdf':
        return pdf_bytes(title, intro, sections), 'application/pdf'
    raise ValueError('支持Markdown、PDF和Word（.docx）格式。')


def docx_bytes(title, intro, sections):
    from docx import Document
    from docx.shared import Cm, Pt, RGBColor
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    document = Document()
    # The bundled template includes theme borders; exported materials use plain headings.
    for style in document.styles:
        for border in list(style.element.iter(qn('w:pBdr'))):
            border.getparent().remove(border)
    section = document.sections[0]
    section.page_width, section.page_height = Cm(21), Cm(29.7)
    section.top_margin = section.bottom_margin = Cm(2)
    section.left_margin = section.right_margin = Cm(2.2)
    for name in ['Normal', 'Title', 'Heading 1', 'List Bullet']:
        style = document.styles[name]
        style.font.name = 'STHeiti'
        style.font.color.rgb = RGBColor(0, 0, 0)
        fonts = style.element.get_or_add_rPr().rFonts
        for attr in list(fonts.attrib):
            if attr.endswith('Theme'):
                del fonts.attrib[attr]
        for attr in ('eastAsia', 'ascii', 'hAnsi', 'cs'):
            fonts.set(qn('w:'+attr), 'STHeiti')
        style.font.size = Pt(11 if name in ['Normal','List Bullet'] else 20 if name=='Title' else 14)
        style.paragraph_format.space_after = Pt(8)
        style.paragraph_format.line_spacing = 1.4
    document.add_paragraph(title, 'Title')
    for line in intro.splitlines():
        document.add_paragraph(line)
    for name, text in sections:
        document.add_paragraph(name, 'Heading 1')
        for line in text.splitlines():
            if not line.strip():
                continue
            is_bullet = bool(re.match(r'^\s*[-*•]\s+', line))
            body = re.sub(r'^\s*[-*•]\s+', '', line)
            paragraph = document.add_paragraph(style='List Bullet' if is_bullet else 'Normal')
            # Real Word numbering, with a Chinese font chosen separately for the symbol.
            if is_bullet:
                numPr = OxmlElement('w:numPr')
                level = OxmlElement('w:ilvl'); level.set(qn('w:val'), '0')
                number = OxmlElement('w:numId'); number.set(qn('w:val'), '1')
                numPr.extend([level, number]); paragraph._p.get_or_add_pPr().append(numPr)
            for i, part in enumerate(re.split(r'\*\*(.*?)\*\*', body)):
                run = paragraph.add_run(part)
                run.bold = i % 2 == 1
            paragraph.paragraph_format.keep_together = True
    output = io.BytesIO()
    document.save(output)
    return output.getvalue()


def pdf_bytes(title, intro, sections):
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.cidfonts import UnicodeCIDFont
    from reportlab.platypus import SimpleDocTemplate, Paragraph
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import cm
    font = 'STSong-Light'
    if font not in pdfmetrics.getRegisteredFontNames():
        pdfmetrics.registerFont(UnicodeCIDFont(font))
    output = io.BytesIO()
    doc = SimpleDocTemplate(output, pagesize=A4, rightMargin=2.2*cm, leftMargin=2.2*cm,
                            topMargin=2*cm, bottomMargin=2*cm, title=title, author='')
    normal = ParagraphStyle('body', fontName=font, fontSize=11, leading=19, spaceAfter=9, wordWrap='CJK')
    bullet = ParagraphStyle('bullet', parent=normal, leftIndent=12, firstLineIndent=-10)
    heading = ParagraphStyle('heading', parent=normal, fontSize=14, leading=22, spaceBefore=16, spaceAfter=9, keepWithNext=True)
    title_style = ParagraphStyle('title', parent=normal, fontSize=21, leading=30, spaceAfter=15)
    story = [Paragraph(escape(title), title_style)]
    story.extend(Paragraph(escape(line), normal) for line in intro.splitlines())
    for name, text in sections:
        story.append(Paragraph(escape(name), heading))
        for line in text.splitlines():
            if not line.strip():
                continue
            is_bullet = bool(re.match(r'^\s*[-*•]\s+', line))
            body = re.sub(r'^\s*[-*•]\s+', '', line)
            # CID font keeps Chinese portable; a small circular marker is drawn as text.
            content = ('• ' if is_bullet else '') + escape(plain(body).replace('÷', '/'))
            story.append(Paragraph(content, bullet if is_bullet else normal))
    doc.build(story)
    return output.getvalue()
