#!/bin/zsh
cd "$(dirname "$0")"
BUNDLED_PYTHON="/Users/qst3.0/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3"
if [[ -x "$BUNDLED_PYTHON" ]]; then
  exec "$BUNDLED_PYTHON" server.py
elif [[ -x .venv/bin/python ]]; then
  exec .venv/bin/python server.py
else
  exec python3 server.py
fi
